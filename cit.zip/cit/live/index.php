<?php
if (isset($_POST['submit'])) {
    //live key to be replaced with the key below
  //MK_PROD_GXWML8TZ66:8M2W57NBD86BZCX76BWRVNYJ8NYUWD56
  // test key
  // MK_TEST_BTTF7KAGTJ:H8L3S4JDUKW9J67ZHCN9NJX2LR5XKQLP
 $login = base64_encode("MK_PROD_GXWML8TZ66:8M2W57NBD86BZCX76BWRVNYJ8NYUWD56"); 
 // echo '<br>';

 $curl = curl_init();
 
 curl_setopt_array($curl, array(
   CURLOPT_URL => "https://api.monnify.com/api/v1/auth/login",
   CURLOPT_RETURNTRANSFER => true,
   CURLOPT_ENCODING => "",
   CURLOPT_MAXREDIRS => 10,
   CURLOPT_TIMEOUT => 0,
   CURLOPT_FOLLOWLOCATION => true,
   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
   CURLOPT_CUSTOMREQUEST => "POST",
   CURLOPT_POSTFIELDS =>'{}',
   CURLOPT_HTTPHEADER => array(
     "Authorization: Basic ".$login,
     "Content-Type: application/json"
   ),
 ));
 
 $response = curl_exec($curl);
 
 curl_close($curl);
 // echo $response;
 
 $value= json_decode($response, true);
 // print_r($value);
 $token = $value["responseBody"]["accessToken"];
 // print( $token);
 //echo $token;
 $ref = $_POST['ref'];
 $email = $_POST['email'];
 header('location:get_reserve_num.php?tok='.$token.'&ref='.$ref.'&email='.$email);
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
input{
    width: 300px;
    height:30px;
}
button{
    padding: 2px 1% 2px 1%;
    font-size: 20px;
}
</style>
<body>
  <center style="margin-top: 100px;">
  <form action="index.php" method="POST">
  <input type="email" name="email" id="" placeholder="email" ><br>
  <input type="text" name="ref" id="" placeholder="name"><br><br>
  <button type="submit"  name="submit">submit</button>
  </form>
  </center>  
</body>
</html>