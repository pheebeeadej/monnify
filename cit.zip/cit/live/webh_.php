<?php
// header('refresh:5;url=webh_.php');
$conn = mysqli_connect('localhost', 'sssiieic_Pheebee', 'toheeb32857831', 'sssiieic_Monnify');

if ($conn) {
    


// Retrieve the request's body and parse it as JSON

    $input = @file_get_contents("php://input");
   
    // Do something with $event
   
    // $event = json_decode($input);
    

     $res = json_decode($input, true);

    //  print_r($res);
     //  $response = file_get_contents("monnify_log.txt");
     
  if (!empty($res)) {
    
    $hash = $res["transactionHash"];
    
    $mnfy_email = $res["customer"]["email"];
         
    $amount_paid = $res["amountPaid"];
    
    $mnfy_trans_ref = $res["transactionReference"];
    
    $payment_status =  $res["paymentStatus"];
    
    $paidon = $res["paidOn"];
    
    $payment_ref = $res["paymentReference"];
    
    $secret_key = "8M2W57NBD86BZCX76BWRVNYJ8NYUWD56"; // replace with live -> 8M2W57NBD86BZCX76BWRVNYJ8NYUWD56

    $transaction_hash  = "$secret_key|$payment_ref|$amount_paid|$paidon|$mnfy_trans_ref";
    
    $verify_hash = hash('sha512', $transaction_hash);
    
    // file_put_contents("monnify_log.txt", $input);

    if ($hash == $verify_hash) {
         
          
                //whether ip is from the share internet  
                 if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                            $ip = $_SERVER['HTTP_CLIENT_IP'];  
                    }  
                //whether ip is from the proxy  
                elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
                 }  
            //whether ip is from the remote address  
                else{  
                         $ip = $_SERVER['REMOTE_ADDR'];  
                 }  
                  
              

        if( $ip == "35.242.133.146"){
                if ($res["paymentStatus"] == "PAID") {
                    $ref = $res["product"]["reference"];
                    //from here you can get the cutomer email if it is uniq in the database or the customer ref $res["customer"]["reference"];
                    // if you use customer reference make sure to pass the uniqe reference in the parameter 
                    // then you use that to credit their account in database
                
                 $str="INSERT INTO cip (id, val , amount) VALUES ('', '$ref', '');";
                 $result = mysqli_query($conn, $str);
                
                  http_response_code(200); // PHP 5.4 or greater
                }else{
                     http_response_code(500);
                }
        }
        
    }

  }
  
  
  // this is the respones that is returned, you can fund the account through any uniqe value
  
  
//   {
//     "transactionReference": "MNFY|05|20210115180436|000235",
//     "paymentReference": "MNFY|05|20210115180436|000235",
//     "amountPaid": "40.00",
//     "totalPayable": "40.00",
//     "settlementAmount": "30.00",
//     "paidOn": "15/01/2021 06:04:36 PM",
//     "paymentStatus": "PAID",
//     "paymentDescription": "adejumohrr",
//     "transactionHash": "c47ad66a0c569f95619883ab182e45349d223c47697157080b5efdff5ab1d90c17b101245932a7fc557f7747cbdd0c83bee16bd6f5181f8523149b7771d5b3bd",
//     "currency": "NGN",
//     "paymentMethod": "ACCOUNT_TRANSFER",
//     "product": {
//         "type": "RESERVED_ACCOUNT",
//         "reference": "adejoh1@gmail.com"
//     },
//     "cardDetails": null,
//     "accountDetails": {
//         "accountName": "Monnify Limited",
//         "accountNumber": "******2190",
//         "bankCode": "001",
//         "amountPaid": "40.00"
//     },
//     "accountPayments": [
//         {
//             "accountName": "Monnify Limited",
//             "accountNumber": "******2190",
//             "bankCode": "001",
//             "amountPaid": "40.00"
//         }
//     ],
//     "customer": {
//         "email": "adejoh1@gmail.com",
//         "name": "adejumohrr"
//     },
//     "metaData": {}
// }

/////////////////////////////////////
//////////////////////////////////////////

}else{
    die("Could not connect ".mysqli_error($conn));
}












