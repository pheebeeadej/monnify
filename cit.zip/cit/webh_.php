<?php
// header('refresh:5;url=webh_.php');
$conn = mysqli_connect('localhost', 'sssiieic_Pheebee', 'toheeb32857831', 'sssiieic_Monnify');

if ($conn) {
    


// Retrieve the request's body and parse it as JSON

    $input = @file_get_contents("php://input");
   
    // Do something with $event
   
    // $event = json_decode($input);
    

     $res = json_decode($input, true);

    //  print_r($res);
     //  $response = file_get_contents("monnify_log.txt");
     
  if (!empty($res)) {
    
    $hash = $res["transactionHash"];
    
    $mnfy_email = $res["customer"]["email"];
         
    $amount_paid = $res["amountPaid"];
    
    $mnfy_trans_ref = $res["transactionReference"];
    
    $payment_status =  $res["paymentStatus"];
    
    $paidon = $res["paidOn"];
    
    $payment_ref = $res["paymentReference"];
    
    $secret_key = "H8L3S4JDUKW9J67ZHCN9NJX2LR5XKQLP"; // replace with live -> 8M2W57NBD86BZCX76BWRVNYJ8NYUWD56

    $transaction_hash  = "$secret_key|$payment_ref|$amount_paid|$paidon|$mnfy_trans_ref";
    
    $verify_hash = hash('sha512', $transaction_hash);
    
    // file_put_contents("monnify_log.txt", $input);

    if ($hash == $verify_hash) {
         
          
                //whether ip is from the share internet  
                 if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                            $ip = $_SERVER['HTTP_CLIENT_IP'];  
                    }  
                //whether ip is from the proxy  
                elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
                 }  
            //whether ip is from the remote address  
                else{  
                         $ip = $_SERVER['REMOTE_ADDR'];  
                 }  
                  
              

        if( $ip == "35.242.133.146"){
                if ($res["paymentStatus"] == "PAID") {
                    $ref = $res["customer"]["reference"];
                    //from here you can get the cutomer email if it is uniq in the database or the customer ref $res["customer"]["reference"];
                    // if you use customer reference make sure to pass the uniqe reference in the parameter 
                    // then you use that to credit their account in database
                
                 $str="INSERT INTO cip (id, val , amount) VALUES ('', '$mnfy_trans_ref', '');";
                 $result = mysqli_query($conn, $str);
                
                  http_response_code(200); // PHP 5.4 or greater
                }else{
                     http_response_code(500);
                }
        }
        
    }

  }
}else{
    die("Could not connect ".mysqli_error($conn));
}












